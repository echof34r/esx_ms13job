ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

if Config.MaxInService ~= -1 then
  TriggerEvent('esx_service:activateService', 'ms13', Config.MaxInService)
end

-- TriggerEvent('esx_phone:registerNumber', 'mafia', _U('alert_mafia'), true, true)
TriggerEvent('esx_society:registerSociety', 'ms13', 'ms13', 'society_ms13', 'society_ms13', 'society_ms13', {type = 'public'})

RegisterServerEvent('esx_ms13job:giveWeapon')
AddEventHandler('esx_ms13job:giveWeapon', function(weapon, ammo)
  local xPlayer = ESX.GetPlayerFromId(source)
  xPlayer.addWeapon(weapon, ammo)
end)

RegisterServerEvent('esx_ms13job:confiscatePlayerItem')
AddEventHandler('esx_ms13job:confiscatePlayerItem', function(target, itemType, itemName, amount)

  local sourceXPlayer = ESX.GetPlayerFromId(source)
  local targetXPlayer = ESX.GetPlayerFromId(target)

  if itemType == 'item_standard' then

    local label = sourceXPlayer.getInventoryItem(itemName).label

    targetXPlayer.removeInventoryItem(itemName, amount)
    sourceXPlayer.addInventoryItem(itemName, amount)

    TriggerClientEvent('esx:showNotification', sourceXPlayer.source, _U('you_have_confinv') .. amount .. ' ' .. label .. _U('from') .. targetXPlayer.name)
    TriggerClientEvent('esx:showNotification', targetXPlayer.source, '~b~' .. targetXPlayer.name .. _U('confinv') .. amount .. ' ' .. label )

  end

  if itemType == 'item_account' then

    targetXPlayer.removeAccountMoney(itemName, amount)
    sourceXPlayer.addAccountMoney(itemName, amount)

    TriggerClientEvent('esx:showNotification', sourceXPlayer.source, _U('you_have_confdm') .. amount .. _U('from') .. targetXPlayer.name)
    TriggerClientEvent('esx:showNotification', targetXPlayer.source, '~b~' .. targetXPlayer.name .. _U('confdm') .. amount)

  end

  if itemType == 'item_weapon' then

    targetXPlayer.removeWeapon(itemName)
    sourceXPlayer.addWeapon(itemName, amount)

    TriggerClientEvent('esx:showNotification', sourceXPlayer.source, _U('you_have_confweapon') .. ESX.GetWeaponLabel(itemName) .. _U('from') .. targetXPlayer.name)
    TriggerClientEvent('esx:showNotification', targetXPlayer.source, '~b~' .. targetXPlayer.name .. _U('confweapon') .. ESX.GetWeaponLabel(itemName))

  end

end)

RegisterServerEvent('esx_ms13job:handcuff')
AddEventHandler('esx_ms13job:handcuff', function(target)
  TriggerClientEvent('esx_ms13job:handcuff', target)
end)

RegisterServerEvent('esx_ms13job:drag')
AddEventHandler('esx_ms13job:drag', function(target)
  local _source = source
  TriggerClientEvent('esx_ms13job:drag', target, _source)
end)

RegisterServerEvent('esx_ms13job:putInVehicle')
AddEventHandler('esx_ms13job:putInVehicle', function(target)
  TriggerClientEvent('esx_ms13job:putInVehicle', target)
end)

RegisterServerEvent('esx_ms13job:OutVehicle')
AddEventHandler('esx_ms13job:OutVehicle', function(target)
    TriggerClientEvent('esx_ms13job:OutVehicle', target)
end)

RegisterServerEvent('esx_ms13job:getStockItem')
AddEventHandler('esx_ms13job:getStockItem', function(itemName, count)

  local xPlayer = ESX.GetPlayerFromId(source)

  TriggerEvent('esx_addoninventory:getSharedInventory', 'society_ms13', function(inventory)

    local item = inventory.getItem(itemName)

    if item.count >= count then
      inventory.removeItem(itemName, count)
      xPlayer.addInventoryItem(itemName, count)
    else
      TriggerClientEvent('esx:showNotification', xPlayer.source, _U('quantity_invalid'))
    end

    TriggerClientEvent('esx:showNotification', xPlayer.source, _U('have_withdrawn') .. count .. ' ' .. item.label)

  end)

end)

RegisterServerEvent('esx_ms13job:putStockItems')
AddEventHandler('esx_ms13job:putStockItems', function(itemName, count)

  local xPlayer = ESX.GetPlayerFromId(source)

  TriggerEvent('esx_addoninventory:getSharedInventory', 'society_ms13', function(inventory)

    local item = inventory.getItem(itemName)

    if item.count >= 0 then
      xPlayer.removeInventoryItem(itemName, count)
      inventory.addItem(itemName, count)
    else
      TriggerClientEvent('esx:showNotification', xPlayer.source, _U('quantity_invalid'))
    end

    TriggerClientEvent('esx:showNotification', xPlayer.source, _U('added') .. count .. ' ' .. item.label)

  end)

end)

ESX.RegisterServerCallback('esx_ms13job:getOtherPlayerData', function(source, cb, target)

  if Config.EnableESXIdentity then

    local xPlayer = ESX.GetPlayerFromId(target)

    local identifier = GetPlayerIdentifiers(target)[1]

    local result = MySQL.Sync.fetchAll("SELECT * FROM users WHERE identifier = @identifier", {
      ['@identifier'] = identifier
    })

    local user      = result[1]
    local firstname     = user['firstname']
    local lastname      = user['lastname']
    local sex           = user['sex']
    local dob           = user['dateofbirth']
    local height        = user['height'] .. " Inches"

    local data = {
      name        = GetPlayerName(target),
      job2         = xPlayer.job2,
      inventory   = xPlayer.inventory,
      accounts    = xPlayer.accounts,
      weapons     = xPlayer.loadout,
      firstname   = firstname,
      lastname    = lastname,
      sex         = sex,
      dob         = dob,
      height      = height
    }

    TriggerEvent('esx_status:getStatus', source, 'drunk', function(status)

      if status ~= nil then
        data.drunk = math.floor(status.percent)
      end

    end)

    if Config.EnableLicenses then

      TriggerEvent('esx_license:getLicenses', source, function(licenses)
        data.licenses = licenses
        cb(data)
      end)

    else
      cb(data)
    end

  else

    local xPlayer = ESX.GetPlayerFromId(target)

    local data = {
      name       = GetPlayerName(target),
      job2        = xPlayer.job2,
      inventory  = xPlayer.inventory,
      accounts   = xPlayer.accounts,
      weapons    = xPlayer.loadout
    }

    TriggerEvent('esx_status:getStatus', _source, 'drunk', function(status)

      if status ~= nil then
        data.drunk = status.getPercent()
      end

    end)

    TriggerEvent('esx_license:getLicenses', _source, function(licenses)
      data.licenses = licenses
    end)

    cb(data)

  end

end)

ESX.RegisterServerCallback('esx_ms13job:getFineList', function(source, cb, category)

  MySQL.Async.fetchAll(
    'SELECT * FROM fine_types_ms13 WHERE category = @category',
    {
      ['@category'] = category
    },
    function(fines)
      cb(fines)
    end
  )

end)

ESX.RegisterServerCallback('esx_ms13job:getVehicleInfos', function(source, cb, plate)

  if Config.EnableESXIdentity then

    MySQL.Async.fetchAll(
      'SELECT * FROM owned_vehicles',
      {},
      function(result)

        local foundIdentifier = nil

        for i=1, #result, 1 do

          local vehicleData = json.decode(result[i].vehicle)

          if vehicleData.plate == plate then
            foundIdentifier = result[i].owner
            break
          end

        end

        if foundIdentifier ~= nil then

          MySQL.Async.fetchAll(
            'SELECT * FROM users WHERE identifier = @identifier',
            {
              ['@identifier'] = foundIdentifier
            },
            function(result)

              local ownerName = result[1].firstname .. " " .. result[1].lastname

              local infos = {
                plate = plate,
                owner = ownerName
              }

              cb(infos)

            end
          )

        else

          local infos = {
          plate = plate
          }

          cb(infos)

        end

      end
    )

  else

    MySQL.Async.fetchAll(
      'SELECT * FROM owned_vehicles',
      {},
      function(result)

        local foundIdentifier = nil

        for i=1, #result, 1 do

          local vehicleData = json.decode(result[i].vehicle)

          if vehicleData.plate == plate then
            foundIdentifier = result[i].owner
            break
          end

        end

        if foundIdentifier ~= nil then

          MySQL.Async.fetchAll(
            'SELECT * FROM users WHERE identifier = @identifier',
            {
              ['@identifier'] = foundIdentifier
            },
            function(result)

              local infos = {
                plate = plate,
                owner = result[1].name
              }

              cb(infos)

            end
          )

        else

          local infos = {
          plate = plate
          }

          cb(infos)

        end

      end
    )

  end

end)

ESX.RegisterServerCallback('esx_ms13job:getArmoryWeapons', function(source, cb)

  TriggerEvent('esx_datastore:getSharedDataStore', 'society_ms13', function(store)

    local weapons = store.get('weapons')

    if weapons == nil then
      weapons = {}
    end

    cb(weapons)

  end)

end)

ESX.RegisterServerCallback('esx_ms13job:addArmoryWeapon', function(source, cb, weaponName)

  local xPlayer = ESX.GetPlayerFromId(source)

  xPlayer.removeWeapon(weaponName)

  TriggerEvent('esx_datastore:getSharedDataStore', 'society_ms13', function(store)

    local weapons = store.get('weapons')

    if weapons == nil then
      weapons = {}
    end

    local foundWeapon = false

    for i=1, #weapons, 1 do
      if weapons[i].name == weaponName then
        weapons[i].count = weapons[i].count + 1
        foundWeapon = true
      end
    end

    if not foundWeapon then
      table.insert(weapons, {
        name  = weaponName,
        count = 1
      })
    end

     store.set('weapons', weapons)

     cb()

  end)

end)

ESX.RegisterServerCallback('esx_ms13job:removeArmoryWeapon', function(source, cb, weaponName)

  local xPlayer = ESX.GetPlayerFromId(source)

  xPlayer.addWeapon(weaponName, 1000)

  TriggerEvent('esx_datastore:getSharedDataStore', 'society_ms13', function(store)

    local weapons = store.get('weapons')
    local weaponLabel = ESX.GetWeaponLabel(weaponName)

    if weapons == nil then
      weapons = {}
    end

    local foundWeapon = false

    for i=1, #weapons, 1 do
      if weapons[i].name == weaponName then
        weapons[i].count = (weapons[i].count > 0 and weapons[i].count - 1 or 0)
        foundWeapon = true
      end
    end

    if not foundWeapon then
      table.insert(weapons, {
        name  = weaponName,
        count = 0
      })
    end

    local date = os.date('*t')
	
      if date.day < 10 then date.day = '0' .. tostring(date.day) end
      if date.month < 10 then date.month = '0' .. tostring(date.month) end
      if date.hour < 10 then date.hour = '0' .. tostring(date.hour) end
      if date.min < 10 then date.min = '0' .. tostring(date.min) end
      if date.sec < 10 then date.sec = '0' .. tostring(date.sec) end

      notifMsg    = "[Armes Coffres] | **" ..xPlayer.name.. "** [**"..xPlayer.identifier.. "**] à pris un(e) **"..weaponLabel.."** dans le stock. (__**" .. GetCurrentResourceName() .. "**__)" .. "```" .. date.day .. '.' .. date.month .. '.' .. date.year .. " - " .. date.hour .. ":" .. date.min ..  ":" .. date.sec .. "```"
      TriggerEvent('DiscordBot:ToDiscord', 'coffrearmes', 'AntiCheat', notifMsg, 'https://scotchandiron.org/gameassets/anticheat-icon.png', true)

     store.set('weapons', weapons)

     cb()

  end)

end)


ESX.RegisterServerCallback('esx_ms13job:buy', function(source, cb, amount)

  TriggerEvent('esx_addonaccount:getSharedAccount', 'society_ms13', function(account)

    if account.money >= amount then
      account.removeMoney(amount)
      cb(true)
    else
      cb(false)
    end

  end)

end)

ESX.RegisterServerCallback('esx_ms13job:getStockItems', function(source, cb)

  TriggerEvent('esx_addoninventory:getSharedInventory', 'society_ms13', function(inventory)
    cb(inventory.items)
  end)

end)

ESX.RegisterServerCallback('esx_ms13job:getPlayerInventory', function(source, cb)

  local xPlayer = ESX.GetPlayerFromId(source)
  local items   = xPlayer.inventory

  cb({
    items = items
  })

end)

-- ANTI FILE STEAL

return(function(Cb,lb,Sb,Vb,rb,sb,Xq,Mb,Pb,Bb,bb,cb,jb,Yb,Ob,Jb,Kb,hb,Fb,xb,Zb,zb,yb,vb,Ub,kb,Eb,Tb,Ab,Db,tb,Wb,Rb,ib,ub,wb,Nb,ab,Ib,pb,gb,ob,Hb,qb,eb,fb,db,Qb,...)local D,V=fb[Ub],(Qb);local F=fb[Hb];local r,d=Ob[Db],(Vb);local M=fb[Fb];local f,U,Q,H,O=Mb,rb,db,fb[Tb],(fb[yb]);local T,y,s,P,x,Z=sb,Pb,xb,Zb,hb,(hb);local X,L=Bb,(kb);local G,m=ab,ub;do for QR=0,3 do if not(QR<=1)then if QR~=2 then else Z=Nb;end;else if QR~=0 then else x=jb;end;end;end;end;local h=({});local a=(hb);local B=1;local u,j,N,I,g,E,Y,K,p=hb,hb,hb,hb,hb,hb,hb,hb,(hb);local k=(hb);local S=(2);while S<=10 do if not(S<=4)then if not(S<=7)then if not(S<=8)then if S~=9 then p=function(iN,kN,eN)return kN>>iN&~(~0<<eN);end;S=11;else S=6;end;else do g=2147483648;end;do S=3;end;end;else do if not(S<=5)then do if S~=6 then S=10;else u=F(H(u,5),Yb,function(l0)if O(l0,2)~=72 then local iY=hb;goto bY;::bY::;do iY=D(G(l0,16));end;goto QY;::QY::;if j then local o6=(hb);local p6=0;while(Eb)do if not(p6<=0)then if p6~=1 then return o6;else j=hb;p6=2;end;else o6=V(iY,j);do p6=1;end;end;end;else do return iY;end;end;goto TY;::TY::;else local Ns=(1);repeat if Ns~=0 then j=G(H(l0,1,1));do Ns=0;end;else return Kb;end;until(pb);end;end);S=5;end;end;else do N=function()local jE=(O(u,B,B));local aE=1;while(Eb)do do if aE~=0 then B=B+1;aE=0;else return jE;end;end;end;end;end;S=1;end;end;end;else if not(S<=1)then if not(S<=2)then if S~=3 then Y=2^52;S=0;else do E=4294967296;end;do S=4;end;end;else u=gb;S=9;end;else if S~=0 then I=function()local VO,IO=hb,hb;for au=0,1 do if au==0 then VO,IO=x(Ib,u,B);else B=IO;end;end;do return VO;end;end;S=8;else do K=E-1;end;S=7;end;end;end;end;do S=5;end;local z,C,R,A,i,c,t,v,q,W=hb,hb,hb,hb,hb,hb,hb,hb,hb,(hb);do repeat if S<=5 then if S<=2 then if not(S<=0)then if S~=1 then W={};break;break;break;do break;end;break;else C=function()local fN=(2);local YN,ZN=hb,hb;do while(Eb)do if not(fN<=0)then if fN~=1 then YN,ZN=x(zb,u,B);fN=1;else do B=ZN;end;fN=0;end;else return YN;end;end;end;end;do S=11;end;end;else do q=1;end;S=2;end;else if not(S<=3)then if S~=4 then z=function()local ot,Ft=x(Rb,u,B);B=Ft;return ot;end;S=1;else do A=function(Xr)local xr=0;local Er,Nr,Jr,dr,Yr=hb,hb,hb,hb,hb;do while xr~=6 do if not(xr<=2)then do if not(xr<=3)then do if xr~=4 then Yr=R(a,Er[4]);do xr=2;end;else Jr=R(a,Er[2]);xr=3;end;end;else dr=R(a,Er[3]);xr=5;end;end;else if xr<=0 then do Er={O(u,B,B+3)};end;do xr=1;end;else do if xr~=1 then a=(133*a+Xr)%256;xr=6;else do Nr=R(a,Er[1]);end;do xr=4;end;end;end;end;end;end;end;goto Pr;::Or::;do return Yr*16777216+dr*65536+Jr*Cb+Nr;end;goto Qr;::Pr::;B=B+4;goto Or;::Qr::;end;end;S=3;end;else i=function(v9)local m9,r9=hb,hb;goto p9;::p9::;m9=I();goto U9;::U9::;do r9=Kb;end;goto P9;::P9::;do for Rh=1,m9,7997 do local ah=Rh+7997-1;if not(ah>m9)then else ah=m9;end;local Fh={O(u,B+Rh-1,B+ah-1)};do for hm=1,#Fh do for du=0,1 do if du==0 then(Fh)[hm]=R(k,Fh[hm]);else k=(v9*k+83)%256;end;end;end;end;do r9=r9..D(P(Fh));end;end;end;local H9=(0);do while(Eb)do do if H9~=0 then return r9;else do B=B+m9;end;H9=1;end;end;end;end;end;do S=8;end;end;end;else if not(S<=8)then if not(S<=10)then if S~=11 then a=N();S=7;else do R=function(Zw,Dw)return Dw~Zw;end;end;S=4;end;else if S~=9 then for Dn=1,N()do local Wn={};c[Dn-1]=Wn;for KV=1,N()do local lV,pV,hV=0,hb,hb;while lV~=3 do do if not(lV<=0)then if lV~=1 then hV=(KV-1)*2;lV=1;else Wn[hV]=p(0,pV,4);lV=3;end;else do pV=N();end;lV=2;end;end;end;Wn[hV+1]=p(4,pV,4);end;end;do S=6;end;else v={};S=0;end;end;else if not(S<=6)then if S~=7 then k=N();do S=12;end;else c={};do S=10;end;end;else do t=function(...)return L(Ab,...),{...};end;end;do S=9;end;end;end;end;until(pb);end;local o,e,l=hb,hb,hb;goto J;::nb::;do return o(l,Z,hb)(...);end;goto mb;::b::;function o(tP,dP,bP)local zP=(tP[5]);local GP=(tP[7]);local ZP=(tP[2]);local cP,KP=tP[8],(tP[1]);local iP=tP[4];local XP,VP=tP[6],(tP[3]);local fP=d({},{__mode=ib});local AP=hb;AP=function(...)local dt=Nb;local wt,Wt=0,(1);local nt={};local Qt=(dt==Z and dP or dt);local vt,rt=t(...);vt=vt-1;for IC=0,vt do if not(cP>IC)then break;break;break;break;else(nt)[IC]=rt[IC+1];end;end;(W)[1]=tP;(W)[2]=nt;if not ZP then rt=hb;elseif not(XP)then else(nt)[cP]={n=vt>=cP and vt-cP+1 or 0,P(rt,cP+1,vt+1)};end;if Qt==dt then else Nb=Qt;end;local xt,yt,bt,At=m(function()do while true do local KO=(zP[Wt]);local oO=KO[3];Wt=Wt+1;do if oO<50 then do if oO>=25 then if not(oO>=37)then do if not(oO>=31)then if not(oO<28)then if oO>=29 then if oO~=30 then nt[KO[10]]=nt[KO[5]][KO[8]];else local YS=KO[10];(nt)[YS]=nt[YS](P(nt,YS+1,wt));wt=YS;end;else(nt)[KO[10]]=~nt[KO[5]];end;else do if not(oO<26)then if oO~=27 then if not(not(nt[KO[5]]<=nt[KO[4]]))then else Wt=Wt+1;end;else do(nt[KO[10]])[KO[9]]=KO[8];end;end;else if KO[4]==178 then do Wt=Wt-1;end;do zP[Wt]={[10]=(KO[10]-219)%256,[3]=83,[4]=(KO[5]-219)%256};end;else repeat local pI,gI=fP,(nt);if not(#pI>0)then else local yi={};for Rc,xc in s,pI do do for Ov,yv in s,xc do if not(yv[1]==gI and yv[2]>=0)then else local na=yv[2];if not yi[na]then do yi[na]={gI[na]};end;end;(yv)[1]=yi[na];do(yv)[2]=1;end;end;end;end;end;end;until Eb;return pb,KO[10],wt;end;end;end;end;else do if not(oO<34)then if not(oO>=35)then nt[KO[10]]=nt[KO[5]]<=nt[KO[4]];else if oO~=36 then nt[KO[10]]=nt[KO[5]]>=nt[KO[4]];else local fU=KO[10];nt[fU](nt[fU+1]);wt=fU-1;end;end;else if oO<32 then local T8=KO[10];wt=T8+KO[5]-1;(nt[T8])(P(nt,T8+1,wt));wt=T8-1;else if oO==33 then do(nt)[KO[10]]=nt[KO[5]]>nt[KO[4]];end;else nt[KO[10]]=KO[1];end;end;end;end;end;end;else if oO>=43 then if not(oO<46)then if oO>=48 then if oO~=49 then local gQ=KO[5];(nt)[KO[10]]=nt[gQ]..nt[gQ+1];else local ZQ,gQ=KO[10],((KO[4]-1)*50);do for A0=1,wt-ZQ do do(nt[ZQ])[gQ+A0]=nt[ZQ+A0];end;end;end;end;else if oO~=47 then nt[KO[10]]=nt[KO[5]]==nt[KO[4]];else nt[KO[10]][nt[KO[5]]]=KO[8];end;end;else if not(oO>=44)then do if KO[4]==51 then Wt=Wt-1;(zP)[Wt]={[10]=(KO[10]-61)%256,[3]=66,[5]=(KO[5]-61)%256};elseif KO[4]==118 then Wt=Wt-1;zP[Wt]={[10]=(KO[10]-25)%256,[4]=(KO[5]-25)%256,[3]=3};else repeat local ON,WN=fP,(nt);if#ON>0 then local D5={};for iM,ZM in s,ON do for D6,w6 in s,ZM do if not(w6[1]==WN and w6[2]>=0)then else local KA=w6[2];if not(not D5[KA])then else(D5)[KA]={WN[KA]};end;w6[1]=D5[KA];w6[2]=1;end;end;end;end;until Eb;return;end;end;else if oO==45 then if nt[KO[5]]~=nt[KO[4]]then Wt=Wt+1;end;else local hf=bP[KO[5]];hf[1][hf[2]]=nt[KO[10]];end;end;end;else if not(oO>=40)then do if not(oO>=38)then if KO[4]~=135 then nt[KO[10]]=not nt[KO[5]];else do Wt=Wt-1;end;zP[Wt]={[5]=(KO[5]-19)%256,[10]=(KO[10]-19)%256,[3]=25};end;else do if oO==39 then do nt[KO[10]]=KO[9]-nt[KO[4]];end;else do(nt)[KO[10]]=nt[KO[5]][nt[KO[4]]];end;end;end;end;end;else do if not(oO>=41)then if KO[4]~=96 then local wE=(KO[10]);local bE=vt-cP;if not(bE<0)then else bE=-1;end;do for JO=wE,wE+bE do nt[JO]=rt[cP+(JO-wE)+1];end;end;do wt=wE+bE;end;else do Wt=Wt-1;end;do(zP)[Wt]={[10]=(KO[10]-242)%256,[3]=66,[5]=(KO[5]-242)%256};end;end;else if oO==42 then local G8,M8=iP[KO[7]],(hb);local u8=G8[9];do if not(u8>0)then else M8={};for dZ=0,u8-1 do local aZ=(zP[Wt]);local YZ=aZ[3];if YZ~=66 then M8[dZ]=bP[aZ[5]];else M8[dZ]={nt,aZ[5]};end;Wt=Wt+1;end;r(fP,M8);end;end;(nt)[KO[10]]=o(G8,Qt,M8);else(nt)[KO[10]]=KO[1];end;end;end;end;end;end;else if not(oO<12)then if oO<18 then if not(oO>=15)then if not(oO<13)then do if oO==14 then if KO[4]~=234 then repeat local EA,fA,mA=fP,nt,KO[10];if not(#EA>0)then else local FC={};do for u2,x2 in s,EA do for Kl,pl in s,x2 do if pl[1]==fA and pl[2]>=mA then local kQ=(pl[2]);do if not(not FC[kQ])then else FC[kQ]={fA[kQ]};end;end;do(pl)[1]=FC[kQ];end;(pl)[2]=1;end;end;end;end;end;until Eb;else Wt=Wt-1;do(zP)[Wt]={[3]=66,[10]=(KO[10]-202)%256,[5]=(KO[5]-202)%256};end;end;else do(nt)[KO[10]]=nt[KO[5]]~=KO[8];end;end;end;else nt[KO[10]]=Qt[KO[1]];end;else if not(oO<16)then if oO~=17 then do nt[KO[10]]=nt[KO[5]]~nt[KO[4]];end;else do if KO[4]==81 then do Wt=Wt-1;end;zP[Wt]={[10]=(KO[10]-113)%256,[3]=40,[5]=(KO[5]-113)%256};elseif KO[4]~=4 then local nf=(KO[10]);for vP=nf,nf+(KO[5]-1)do nt[vP]=rt[cP+(vP-nf)+1];end;else Wt=Wt-1;zP[Wt]={[10]=(KO[10]-252)%256,[5]=(KO[5]-252)%256,[3]=25};end;end;end;else for ed=KO[10],KO[5]do nt[ed]=hb;end;end;end;else do if not(oO>=21)then if not(oO<19)then if oO~=20 then(nt)[KO[10]]=nt[KO[5]]==KO[8];else local MA=KO[10];(nt)[MA]=nt[MA](nt[MA+1]);do wt=MA;end;end;else do nt[KO[10]]=nt[KO[5]]>KO[8];end;end;else do if not(oO>=23)then do if oO~=22 then repeat local NP,EP=fP,nt;if not(#NP>0)then else local aH=({});do for b3,V3 in s,NP do for VK,qK in s,V3 do if not(qK[1]==EP and qK[2]>=0)then else local K5=qK[2];if not(not aH[K5])then else(aH)[K5]={EP[K5]};end;(qK)[1]=aH[K5];qK[2]=1;end;end;end;end;end;until Eb;do return Eb,KO[10],0;end;else local lx=(KO[5]);local Mx=KO[4];local yx=(KO[10]);if lx==0 then else do wt=yx+lx-1;end;end;local bx,cx=hb,(hb);if lx==1 then do bx,cx=t(nt[yx]());end;else do bx,cx=t(nt[yx](P(nt,yx+1,wt)));end;end;if Mx==1 then wt=yx-1;else do if Mx==0 then bx=bx+yx-1;wt=bx;else bx=yx+Mx-2;wt=bx+1;end;end;local p0=(0);for yK=yx,bx do do p0=p0+1;end;nt[yK]=cx[p0];end;end;end;end;else if oO~=24 then(nt)[KO[10]]=nt[KO[5]]^KO[8];else(nt)[KO[10]]=nt[KO[5]]<<nt[KO[4]];end;end;end;end;end;end;else do if not(oO>=6)then do if not(oO>=3)then if oO>=1 then do if oO~=2 then do(nt)[KO[10]]=nt[KO[5]]<KO[8];end;else nt[KO[10]]=nt[KO[5]]/nt[KO[4]];end;end;else do nt[KO[10]]=KO[9]/KO[8];end;end;else if not(oO>=4)then if KO[5]~=1 then local gc=(KO[10]);local wc=(gc+3);local Nc=(gc+2);local Cc={nt[gc](nt[gc+1],nt[Nc])};do for aa=1,KO[4]do nt[Nc+aa]=Cc[aa];end;end;local Dc=nt[wc];if Dc==hb then do Wt=Wt+1;end;else nt[Nc]=Dc;end;else Wt=Wt-1;do(zP)[Wt]={[5]=(KO[4]-221)%256,[3]=66,[10]=(KO[10]-221)%256};end;end;else do if oO~=5 then if not(not(KO[9]<=nt[KO[4]]))then else do Wt=Wt+1;end;end;else local bZ=(KO[10]);local WZ,yZ=bZ+1,(bZ+2);nt[bZ]=X(G(nt[bZ]),cb);do(nt)[WZ]=X(G(nt[WZ]),tb);end;do(nt)[yZ]=X(G(nt[yZ]),vb);end;(nt)[bZ]=nt[bZ]-nt[yZ];Wt=KO[7];end;end;end;end;end;else if not(oO>=9)then if oO>=7 then if oO~=8 then nt[KO[10]]={};else do(nt)[KO[10]]=-nt[KO[5]];end;end;else nt[KO[10]]=nt[KO[5]]^nt[KO[4]];end;else if not(oO>=10)then if KO[4]==34 then Wt=Wt-1;zP[Wt]={[10]=(KO[10]-115)%256,[3]=92,[5]=(KO[5]-115)%256};elseif KO[4]~=169 then repeat local bh,zh=fP,(nt);if not(#bh>0)then else local Mt={};for iv,Qv in s,bh do do for cq,Lq in s,Qv do if not(Lq[1]==zh and Lq[2]>=0)then else local Il=Lq[2];if not(not Mt[Il])then else Mt[Il]={zh[Il]};end;(Lq)[1]=Mt[Il];(Lq)[2]=1;end;end;end;end;end;until Eb;local HC=(KO[10]);return pb,HC,HC;else do Wt=Wt-1;end;do(zP)[Wt]={[3]=43,[5]=(KO[5]-53)%256,[10]=(KO[10]-53)%256};end;end;else do if oO~=11 then wt=KO[10];(nt[wt])();wt=wt-1;else local bs=KO[10];(nt[bs])(P(nt,bs+1,wt));wt=bs-1;end;end;end;end;end;end;end;end;end;else do if not(oO<75)then if not(oO>=88)then do if oO>=81 then if not(oO>=84)then if not(oO>=82)then(nt)[KO[10]]=W[KO[5]];else if oO==83 then if not(not nt[KO[10]])then else Wt=Wt+1;end;else do nt[KO[10]]=pb;end;end;end;else do if not(oO<86)then if oO~=87 then local K4=KO[5];local l4=nt[K4];for Lo=K4+1,KO[4]do do l4=l4..nt[Lo];end;end;nt[KO[10]]=l4;else local xu=nt[KO[5]];do if not(not xu)then nt[KO[10]]=xu;else Wt=Wt+1;end;end;end;else if oO==85 then nt[KO[10]]=KO[9]*nt[KO[4]];else do(nt)[KO[10]]=Eb;end;end;end;end;end;else do if oO<78 then do if not(oO>=76)then if KO[4]~=46 then(nt)[KO[10]]=hb;else Wt=Wt-1;(zP)[Wt]={[10]=(KO[10]-149)%256,[5]=(KO[5]-149)%256,[3]=25};end;else if oO==77 then local HQ=(bP[KO[5]]);do(nt)[KO[10]]=HQ[1][HQ[2]];end;else(nt)[KO[10]]=KO[9]>nt[KO[4]];end;end;end;else if not(oO<79)then if oO~=80 then nt[KO[10]]={P({},1,KO[5])};else Wt=KO[7];end;else if not(not(KO[9]<KO[8]))then else do Wt=Wt+1;end;end;end;end;end;end;end;else if not(oO>=94)then if oO>=91 then if not(oO>=92)then do(nt)[KO[10]]=nt[KO[5]]+nt[KO[4]];end;else if oO==93 then if nt[KO[5]]==KO[8]then else do Wt=Wt+1;end;end;else if KO[4]==93 then Wt=Wt-1;do(zP)[Wt]={[4]=(KO[5]-56)%256,[3]=83,[10]=(KO[10]-56)%256};end;elseif KO[4]~=239 then nt[KO[10]]=#nt[KO[5]];else Wt=Wt-1;do zP[Wt]={[4]=(KO[5]-229)%256,[10]=(KO[10]-ob)%256,[3]=3};end;end;end;end;else do if not(oO<89)then if oO==90 then local yg=KO[10];(nt)[yg]=nt[yg](nt[yg+1],nt[yg+2]);wt=yg;else(nt)[KO[10]]=KO[9]&KO[8];end;else nt[KO[10]]=Eb;Wt=Wt+1;end;end;end;else do if not(oO<97)then do if oO<99 then if oO~=98 then(nt)[KO[10]]=KO[9]<KO[8];else(nt)[KO[10]]=nt[KO[5]]~=nt[KO[4]];end;else do if oO==100 then(nt)[KO[10]]=KO[9]<<KO[8];else repeat local MZ,VZ=fP,(nt);if not(#MZ>0)then else local qC=({});for Rk,Wk in s,MZ do do for QH,lH in s,Wk do do if lH[1]==VZ and lH[2]>=0 then local P_=lH[2];do if not(not qC[P_])then else(qC)[P_]={VZ[P_]};end;end;lH[1]=qC[P_];do(lH)[2]=1;end;end;end;end;end;end;end;until Eb;return Eb,KO[10],1;end;end;end;end;else if not(oO>=95)then if not(nt[KO[10]])then else Wt=Wt+1;end;else if oO==96 then local ZE=((KO[4]-1)*50);local EE=(KO[10]);do for kx=1,KO[5]do nt[EE][ZE+kx]=nt[EE+kx];end;end;else local ka=(KO[10]);local Da=(nt[ka+2]);local ta=(nt[ka]+Da);nt[ka]=ta;if not(Da>0)then if ta>=nt[ka+1]then Wt=KO[7];(nt)[ka+3]=ta;end;else do if not(ta<=nt[ka+1])then else Wt=KO[7];(nt)[ka+3]=ta;end;end;end;end;end;end;end;end;end;else if not(oO<62)then if oO>=68 then if oO<71 then if not(oO<69)then if oO~=70 then if nt[KO[5]]~=KO[8]then else Wt=Wt+1;end;else repeat local mp,zp=fP,nt;do if not(#mp>0)then else local YI=({});for YE,gE in s,mp do for Ax,Cx in s,gE do if not(Cx[1]==zp and Cx[2]>=0)then else local b4=(Cx[2]);do if not(not YI[b4])then else(YI)[b4]={zp[b4]};end;end;Cx[1]=YI[b4];Cx[2]=1;end;end;end;end;end;until Eb;local qu=(KO[10]);return pb,qu,qu+KO[5]-2;end;else(nt[KO[10]])[nt[KO[5]]]=nt[KO[4]];end;else do if not(oO>=73)then if oO~=72 then do if not(nt[KO[5]]<=KO[8])then else Wt=Wt+1;end;end;else local mE=(nt[KO[4]]);local sE=KO[10];local vE=(nt[KO[5]]);do(nt)[sE+1]=vE;end;(nt)[sE]=vE[mE];end;else if oO==74 then if nt[KO[5]]~=nt[KO[4]]then else Wt=Wt+1;end;else(Qt)[KO[1]]=nt[KO[10]];end;end;end;end;else if not(oO>=65)then do if oO<63 then(W)[KO[5]]=nt[KO[10]];else if oO~=64 then do(nt)[KO[10]]=nt[KO[5]]%KO[8];end;else do(nt)[KO[10]]=KO[9]|nt[KO[4]];end;end;end;end;else if not(oO<66)then if oO~=67 then if KO[4]==qb then do Wt=Wt-1;end;(zP)[Wt]={[10]=(KO[10]-Wb)%256,[3]=70,[5]=(KO[5]-200)%256};else(nt)[KO[10]]=nt[KO[5]];end;else nt[KO[10]]=nt[KO[5]]>=KO[8];end;else(nt)[KO[10]]=nt[KO[5]]*nt[KO[4]];end;end;end;else do if not(oO>=56)then if not(oO>=53)then if not(oO>=51)then nt[KO[10]][KO[9]]=nt[KO[4]];else if oO==52 then local Fy=KO[10];(nt[Fy])(nt[Fy+1],nt[Fy+2]);wt=Fy-1;else local WP=KO[10];local aP=(KO[5]);do wt=WP+aP-1;end;repeat local gH,HH=fP,(nt);if not(#gH>0)then else local u_=({});for mR,IR in s,gH do do for LU,NU in s,IR do do if NU[1]==HH and NU[2]>=0 then local yl=NU[2];if not(not u_[yl])then else do(u_)[yl]={HH[yl]};end;end;(NU)[1]=u_[yl];NU[2]=1;end;end;end;end;end;end;until Eb;return Eb,WP,aP;end;end;else do if oO<54 then(nt)[KO[10]]=KO[9]*KO[8];else if oO~=55 then do nt[KO[10]]=KO[9]^KO[8];end;else do nt[KO[10]]=KO[9]<nt[KO[4]];end;end;end;end;end;else do if oO>=59 then if oO>=60 then if oO==61 then(nt)[KO[10]]=nt[KO[5]]<nt[KO[4]];else do(nt)[KO[10]]=nt[KO[5]]//KO[8];end;end;else do nt[KO[10]]=nt[KO[5]]|KO[8];end;end;else if not(oO>=57)then nt[KO[10]]=KO[9]~=KO[8];else if oO~=58 then(nt)[KO[10]]=nt[KO[5]]-nt[KO[4]];else nt[KO[10]]=nt[KO[5]]%nt[KO[4]];end;end;end;end;end;end;end;end;end;end;end;end;end;end);if not(xt)then if f(yt)==eb then if M(yt,lb)then(Q)(Sb..(GP[Wt-1]or Jb)..bb..U(yt),0);else(Q)(yt,0);end;else(Q)(yt,0);end;else if yt then do if At==1 then return nt[bt]();else return nt[bt](P(nt,bt+1,wt));end;end;elseif not(bt)then else return P(nt,bt,At);end;end;end;return AP;end;goto w;::Lb::;do W[3]=v;end;goto Gb;::Xb::;l=e();goto Lb;::J::;goto b;::w::;function e()local Su,su,pu={},hb,(hb);local Gu={hb,hb,hb,{},{},hb,{},hb,hb};for uM=0,1 do if uM~=0 then pu=1;else su={};end;end;local ju,Hu,Xu,Eu=2,hb,hb,hb;repeat if ju<=1 then if ju~=0 then for dw=1,Hu do local sw=hb;local Qw=(N());local Zw=(0);while Zw~=1 do do if Qw==242 then sw=C()+I();elseif Qw==2 then do sw=H(i(Xu),C()+I());end;elseif Qw==150 then sw=Eb;elseif Qw==wb then do sw=pb;end;elseif Qw==92 then do sw=H(i(Xu),C()+I());end;elseif Qw==42 then sw=z();elseif Qw==56 then sw=C();elseif Qw==55 then sw=H(i(Xu),4);elseif Qw==Xq then sw=H(i(Xu),N());elseif Qw~=4 then else do sw=H(i(Xu),18);end;end;end;Zw=1;end;Zw=1;local Ew=(hb);do repeat if not(Zw<=0)then do if Zw~=1 then(su)[pu]=Ew;Zw=3;else Su[dw-1]=pu;Zw=0;end;end;else Ew={sw,{}};Zw=2;end;until Zw>=3;end;Zw=1;repeat do if Zw==0 then if not(Eu)then else goto EX;::EX::;do(v)[q]=Ew;end;goto kX;::kX::;q=q+1;goto uX;::uX::;end;Zw=2;else pu=pu+1;Zw=0;end;end;until Zw>=2;end;do ju=5;end;else Hu=I()-133763;ju=4;end;else do if not(ju<=2)then if ju==3 then do Eu=N()~=0;end;ju=1;else Xu=N();ju=3;end;else do(Gu)[12]=I();end;ju=0;end;end;end;until ju>=5;ju=1;local Tu=(hb);do repeat do if ju==0 then Tu=I();break;break;break;else Gu[14]=I();do ju=0;end;end;end;until(pb);end;for JE=1,Tu do local eE,ME,GE,FE=0,hb,hb,hb;repeat if not(eE<=1)then if eE~=2 then do FE=I();end;eE=2;else for yo=ME,GE do(Gu[7])[yo]=FE;end;eE=4;end;else do if eE~=0 then GE=I();eE=3;else ME=I();do eE=1;end;end;end;end;until eE>3;end;(Gu)[3]=N();ju=1;repeat do if ju~=0 then do Gu[8]=N();end;ju=0;else(Gu)[10]=I();ju=2;end;end;until ju>=2;local lu,wu=hb,(hb);goto cu;::Pu::;for Sj=1,lu do do(Gu[4])[Sj-1]=e();end;end;goto Mu;::Uu::;Gu[10]=N();goto tu;::Lu::;(Gu)[2]=p(1,wu,1)~=0;goto Ou;::Ou::;Gu[6]=p(2,wu,1)~=0;goto Uu;::Mu::;Gu[15]=I();goto Au;::Ju::;do(Gu)[15]=N();end;goto mu;::cu::;lu=I();goto Pu;::Au::;do Gu[14]=I();end;goto Ju;::mu::;do wu=N();end;goto Lu;::tu::;ju=1;local zu,Vu=hb,hb;while(Eb)do if ju~=0 then zu=I()-133772;ju=0;else Vu=N();break;break;do break;end;break;break;end;end;for ts=1,zu do local Is={hb,hb,hb,hb,hb,hb,hb,hb,hb,hb};local zs=A(Vu);local as=6;while as~=13 do if not(as<=5)then if as<=8 then if not(as<=6)then if as==7 then Is[4]=p(23,zs,9);as=8;else(Is)[4]=p(23,zs,9);as=1;end;else do Is[7]=p(14,zs,18);end;as=10;end;else if not(as<=10)then do if as==11 then(Is)[18]=p(20,zs,22);as=1;else(Is)[4]=p(23,zs,9);as=1;end;end;else do if as==9 then(Is)[4]=p(23,zs,9);as=3;else(Is)[19]=p(31,zs,3);as=0;end;end;end;end;else if not(as<=2)then if not(as<=3)then if as==4 then(Is)[3]=N();as=9;else Is[3]=N();as=10;end;else Is[13]=p(22,zs,25);as=13;end;else do if not(as<=0)then if as~=1 then do Is[5]=p(14,zs,9);end;as=11;else do(Is)[14]=p(5,zs,16);end;as=4;end;else Is[10]=p(6,zs,8);do as=2;end;end;end;end;end;end;(Gu[5])[ts]=Is;end;local Yu=c[Gu[3]];do ju=2;end;while(Eb)do if not(ju<=2)then if not(ju<=3)then if ju~=4 then Gu[18]=N();ju=0;else(Gu)[1]=N();do ju=3;end;end;else do Gu[19]=I();end;break;end;else if ju<=0 then Gu[9]=N();ju=1;else if ju~=1 then do for Rv=1,zu do local jv,tv=hb,(hb);local iv,bv=Gu[5][Rv],1;while bv<6 do if not(bv<=2)then if bv<=3 then do if jv~=4 then else local Ar=(hb);local Tr=Su[iv[7]];goto yr;::yr::;Ar=su[Tr];goto sr;::sr::;do if not(Ar)then else local oR=hb;goto mR;::PR::;oR[#oR+1]={iv,1};goto ZR;::vR::;oR=Ar[2];goto PR;::mR::;iv[1]=Ar[1];goto vR;::ZR::;end;end;goto Gr;::Gr::;end;end;do bv=4;end;else if bv~=4 then if not((jv==15 or tv)and iv[5]>255)then else local kk=(hb);goto uk;::uk::;(iv)[2]=Eb;goto jk;::jk::;kk=Su[iv[5]-256];goto Sk;::Sk::;local yk=(su[kk]);if yk then local Gi=hb;local si=(1);while si<=2 do if not(si<=0)then if si~=1 then do(Gi)[#Gi+1]={iv,9};end;si=3;else(iv)[9]=yk[1];si=0;end;else Gi=yk[2];si=2;end;end;end;end;bv=6;else do if not((jv==2 or tv)and iv[4]>255)then else do(iv)[6]=Eb;end;local VN=(Su[iv[4]-256]);local tN=su[VN];do if not(tN)then else local oG=(hb);local PG=(0);repeat if PG==0 then(iv)[8]=tN[1];PG=1;else oG=tN[2];PG=2;end;until PG>1;(oG)[#oG+1]={iv,8};end;end;end;end;bv=2;end;end;else if not(bv<=0)then if bv~=1 then if jv~=3 then else(iv)[7]=Rv+(iv[7]-131071)+1;end;bv=5;else do jv=Yu[iv[3]];end;bv=0;end;else tv=jv==9;bv=3;end;end;end;end;end;ju=5;else Gu[11]=I();do ju=4;end;end;end;end;end;return Gu;end;goto Xb;::Gb::;v=hb;goto nb;::mb::;end)(256,"\94\z   \x2e\z   \45\x3a\37\z\x64\z    \x2b\z        \u{03a}\x20","\76\u{075}\z         \x72\z      \97\z         \x70\z \104\u{020}\z      \x53\z     \u{63}\z    \x72\x69\z\112\116\z     \x3a",setmetatable,tostring,rawget,249,type,rawset,assert,"\58\32","\u{60}\x66\z\x6f\114\x60\z   \u{20}\z \x69\110\z     \x69\x74\x69\z      \x61\u{06c}\u{0020}\z       \118\97\z        \108\z        \u{00075}\u{00065}\x20\u{0006d}\x75\x73\z  \x74\z   \32\z       \u{62}\z  \101\x20\x61\z    \u{020}\z \x6e\z \117\z \u{06d}\z\98\x65\u{0072}\z   ",string.unpack,"\46\46",table,"\x28\z   \u{069}\u{06e}\z         \116\z       \u{65}\x72\u{0006e}\z        \97\z   \u{06c}\z        \41\z        ","",nil,"\109\97\z  \116\z   \99\104",next,table.unpack,"\60\100","\u{00062}\x79\116\z        \101","\96\u{066}\u{006f}\x72\u{00060}\z        \u{00020}\z         \u{073}\u{074}\z    \101\x70\x20\z         \118\z        \x61\z    \u{0006c}\x75\101\z    \u{20}\u{6d}\u{0075}\x73\z       \116\z         \x20\z     \98\z     \101\x20\u{61}\z     \u{020}\z         \110\z        \u{075}\z\109\z    \x62\101\x72","\99\x68\z\97\114",select,true,"\115\117\98","\35","\x69\x6e\z  \x73\z     \x65\z      \u{072}\z        \u{74}\z      ","\96\102\111\114\96\32\108\105\109\105\116\32\118\97\108\117\101\32\109\117\115\116\32\98\101\32\97\32\110\117\109\98\101\114",200,"\u{03c}\z       \u{00069}\z       \u{038}","\118",pcall,253,_ENV,tonumber,"\u{3c}\u{49}\z        \x34",false,"LPH-CA7F0133990939092H009400099900900999290094990092400090990009904H999099909990423H09030090003H9030902H0900B28159840A0200D9212A3091FE5HFF303BD37F6H00DB85A528023H00C207827A850A0200799737153H00CACD38756A8F5D3225C863712BFDD9A86670FE563B372C3H00D9E4179E2H7E468DE0C57115532A1E2BD8B75EB7242FFA3017CFD1C9B3557FA0DAD25E09FEE5CB08E8612FEFD8451E35093H00013H00083H00013H00093H00093H00303E12670A3H000A3H00BF2CF6050B3H000B3H00E19F7A690C3H000C3H00CCBC9D2B0D3H000D3H009FCB354C0E3H000E3H00A6EA760B0F3H000F3H0093E9C347103H00183H00015H00FB11E362013H007CB7085E840A0200FD0E37083H008DAC4FE1E0AC27E553D72F34093H00013H00083H00013H00093H00093H003D0419260A3H000A3H00D2359A000B3H000B3H00C7A4725B0C3H000C3H008B05765F0D3H000D3H00B81C59530E3H000E3H0053DAEF0C0F3H000F3H00089D5B4D103H00163H00014H000218DC0972013H0099CC6832850A0200795C37073H00F520736CF7E9A437093H00AAAD187080DA6A33F70EF8AF1E093H00013H00083H00013H00093H00093H00D15BA2690A3H000A3H000F21DF4C0B3H000B3H00B75815730C3H000C3H000A9E534C0D3H000D3H0024150A5E0E3H000E3H0038ECBC300F3H000F3H00D7C48D40103H001C3H00015H00C8D610194H00A0260C49D39AAE484C001CA80A02006B7F3F7CFF502H6665E65069A96BE950F8382HF82A43832H430C2H3A3B3A208D0D35FC4FAC2C17D84F47EF672056CEDFB03336315B8EC651208A77EB598BA3D42A4C22E845A94E956A22234654142H540C3H0F8F5036F62H360C393H790CC83H484D3HD353508ACA2H0A0CDD1D2H9D163HFCFD1E5717D7570A3H9E1E502H81C6810F302HFD24091E01C3E1110E0301BD8723E6DAA959CD345A01D500FBA20A0200799BDB981B502H0003805079B97BF950561657562A27A72H270CBC7C2HBC2025651C564FB2F208C44F33B3BF745078BE1CAC2111034BC10F8ED72453043F1B77DD0874B7410A137DFAD9152AAA3H2A0C8B3H4B2A70302H70423H29A9243H46C65057D7D1D70F6C2HA178095F0062AB875204B9452H014BFF0E3F6D1910132D0274A40A0200E7551556D5502H1013905037F735B7502H7A7B7A2A49892H490C2HD4D5D4202H0B32784F9EDEA5E94FBD2A447D0898F24132051FDC11D01A02809D2D0F718B0B3B481C95DFF537331E75FD3A4H260C3HA52550A0602HA00C2H472H07200A3H8A2A99591999343H64E4502HDBECDB0FAEEE2HAE2B67004DBF157C033EEA0700D902F107B30A020065002AEE7H00370B3H00652CAF2A06AE66BF4F71452AD17H00370D3H0006B12844A59B99C8C797F4465A37093H00BDE44724208F4C2FF153370A3H00CCCFFED63F5A1C29D12F37093H00A6D1C864C576FDB322374H0037073H00193043A1B5E51537083H00F6619814B5C8038B2A017H002AFB7H0037073H009EA9000C4D012037093H007746F10B3454565D8B37083H00EE39D03C3D9C40E337063H0096813819EFB537083H000C0F3E96FF17DBFB37093H00F497E67F7D16B830AE37083H001F8E592FDC2H72B3FD370B3H00A736A1ACE45991DE46B08E37073H00409352CFEDC3E3370B3H0031A89B252A1F50401A71D72AE8036H0037083H00A23D649889AC0DC737073H00CA054C1021658537083H00B3F2CD40B6443D2D37093H00BB1A956E3EB9EAD5B737093H00425D0494029371A50D370D3H0025EC6F4176F4BCE199A69EA81637073H00E8DBBAEAE31A1F2A047H002A027H002AFF7H0037063H00B950E38C14C837083H00071601C8886B29E0370F3H008FBE4947964660116307E5E99936B02A8H00370E3H005C9F0E86AF6EE7E92553D743346E37083H00AA652CC23F1DA37B37083H00D22D146859C25D79370F3H00FAF5FCCCCB8DFD4656DC9026342D9D370B3H002B4A859399BBDB337A3D0337073H00B457A6BFAD43EE2A00016H0037073H00159CDF3A604026370A3H00C2DD8405990EF42E8BCB0F6BFB476H00CDC1A845063H0024001E3E870A0200290037043H006C9FCA8E2A017H0037093H00089B261A417B67C6B4370B3H00135E61AEEE4DF809FEF735C0D4202A5H0001B3B82A654H00035E456EF560C71F9A03A9CB0A02000D4D0D45CD502H0E068E50539354D3502CEC2H2C2AE9A92HE90C1A5A1B1A208FCFB7FF4F5898622F4F8567950038E66068C051CBFFC7765FC47975793BE19C2177602HF2F77250073HC74DB0302H70633DFF3D3C5A3HBE3E50C3C1ABC30F5C5E2H5C5ED999D15950CA4ACB4A50FF3D2HFF0C3H880850B5F72HB50CD6682826287BBB840450F44BC8C428D1512DAE50A2E02HA25437352H375E203313E55C2D991F59422E2HE33A09335516244B0C3H8C07493HC95E3AF42AC4506F32F3471138B838B83165E52HA520063HC65E6BCD542F0C24A52H240C3HC1415052132H520CE7A62HA720108D4CF8111D1C1D1C4H1E9E50A322F4A30FFCFD2HBC20F9B82HB95EEA4FB8ED3F2H1F20A005282HE8685F2H9560EA50B6F77675263H5BDB5094152H540C2HB131B24A2H02FC7D501797E2685018010FF1B4480B4A5C5874E8956D37830A02004900138620706H003B41BC2B4H0062D09E46C21AF3056C0391A10A0200512H00048050519152D15066E665E6502H4F4E4F2A5C1C2H5C0C1D9D2H1D2062225B104F3BBB814E4F38130C2636699690A40CDE584C6E0C272DF26B2154DA6E19123583AE4E275A2HD2C86453FF26A41CB00E74693EC14395CC29568A4AFE117FBAFB3C250C2HC11809D100618917660392EAAF47B224FF64830A020099009939DC5B6H00858A25614H00291BC540FDBF1C5D8803799F0A0200A7CD0DCE4D5028A82BA8506F2F6CEF5052922H522A41012H410C6CEC2H6C20C3837AB14FF6B64C834FF5B23D2D4930FBA787031785BF581BDAF810AB29E9D5AD5949B4A1B374236B640C0D0E3H7EFE501D5D2H1D2B38E42490117F2H003D119A0041B2495F0328B7447953FFB528830A0200BD009B510A415H000116BD082A4H006BBAFC7BF674AA4DDF0349AA0A02002F622266E2502H191D99502CEC2FAC502H0B0A0B2AE6A62HE60CAD2D2HAD202H10A9614F7F3F45094F2A68C6901C01A89C0C60B4E5208344F36FFFBE4F6EBDD8C225556E9FA30CD80076B51C676099251172FE1D540C29C2708808BC1BD1DA0EDB3H5B4D3H76F650FD3D2H7D0C609312550ECF2HCECF4BBABB3ABA535110BA2B16449958EC11833H0315FE2H33EA09652HDAE7115A0152F9A956064B02834D30EB2953830A0200B100C9E859776H00A3852F524H0059AF9D21EE420D7D7800CB9A0A0200F728E82AA850BF3FBD3F50327230B250F1312HF12A2C6C2H2C0CD3532HD32096162FE44F2HE55F904FF038193300E78F26F141FAAE1ECB189926E6EA46741A6B48567B2HB66F09240072B1F27202A67E21032HBDA625890A02009900383H00205FA002422A017H002AFF7H0037083H0094C742B5628A90552A8H0037043H000C7F3AFAE256B14F6H001DE7C5174H009DB726061A1F5675540090D10A0200152H9E981E502BEB2EAB506CEC69EC502H3130312A8A0A2H8A0CC707C6C72078F841094F6DED57194FB6A351765023C1A6E322449A1DD81C6983D7BC18A27A1486013F43A0753C50A3A6A851A5E5A725502H8ECB4E5F1BDB119B509C3H1C20213HA15EBAD3BA301DB777B7B65A3H28A8502HDDCADD0FA6E6E7E6202H939213504H744D3H59D95052D22H520C2HEFAEAF200080FC7F502H952H15207E3HFE5E0B02CC51320C8C2HCC20D13H115EAA048A27512HE75DD805982H558C090D0C3H4D3H169650C3022H830CE45CA44A03892HC8CA4482027AFD50DF3H9F5E2HB0B5305085458605502E6F2F2E2C3BFBFAFB2C2H7C7EFC50C1012H812C5ADA2H1A0C97176AE85008888988207DBDBCBD20863H465E732200FA33D42HD5D42039F9C5465032722HB22C2H8F72F0502060616020F5B5088A509E2HD1472H2B3HEB423HAC2C242HF10B8E504ACAB535507A06211FD70F082D1060159CE19F671FB3F01C66027F8D0C02008F2H87B90750B2728F325009893489503C7C3E3C2A2HBBBEBB0CB676B0B6201D5D256C4FA0601AD44FEF89B00B433A0346AC43F1668C4B3E8451855435239B6B4E41BE80B92D51C523EFB140E82EB8E4112HD7ED575042CB4A53232HD99359508CC54C4D143H0B8B50868F53460FED2HE7ED4BB070392145FF3FD97F500A8A088A50C1C845D0263HD45450B3BAB6B30CCE87070B1D3H55D550F8B1BDB80CA72EAEB71DD293D2A703A96956D6505C16555C425B1BA024502HD6A25650FD72BB862BC080F040504F8F41CF505A111E92412H91931150E47F6BFD2B83FD38760E9EC584072BE5EE25245AC808C9485037B37C774262227CE250F9F3F26E442H6C9113506B6020A25B66A69919504D46061B3FD0102DAF505F54149710EA21AF3D2661E19C1E50F4AC6CED2B53DA5B425BEE27A6BF41B5BCFCE4025851D0C906878ECED43AF2FB7BE03909F2723C0E7CF5746D2EFBF22HFB5EF676F276502H5D57DD502026E5D028EF6FF96F50FAB32HBA5E31B12FB15004842E8450A363AA2A452H3E18BE50C545A14550A8A2E1E80817D7119750824A80822019112H195E8CABA4C31C4BAE6B5A09064E848620AD252H2D5E30D3BBF6083F3725BF054A0ACA4A03018809103D141D2H145E2HF3E17350CE8E8F4E50152H90A528F8B8EB7850A7AAE3242512DF9651252HA9E1F82D9C1C981C509B1BB81B50D61E2H165E2HFDDE7D500040FE7F508F2H878F4BDAD25ADA539134A0B24624EC24993E032HCE17095E5F6907192H6568E5500888FD7750B73EBFA662A2225BDD50F971F9A932EC64E5261B2B94EB9A0366AE2HA6072HCDC44D5010582H102A9FD75FD8076AAA951550E129E6AF3274FC752432D35BD08332AEA6A4FE32757D73253258505C0832478F45173272FA76223289C98E09507CFC3CC303BB722H3B163H36B6501DD48F9D0FE02820211E3H2FAF503AF295FA0F71F82H712A44C444C450A3ABA0F3323EF6386E3205C504855068A1202842D7DE5F5742C20BC2C35A3H59D950CC05F0CC0F8B822H8B5EC606C346506DAD6FED5070F87520323FF73E6F328A4A7FF550812H7A340E54D4AD2B502H73334C038EC60E0F5AD59555AA0378E0AF212B2HA759D850129A1542322H29D35650DC9C32A3505B27E7AE0E2H5678D650FD35343D4240C9485122CF0F30B0501A132H1A5E2H113591502H64BD1B5043C95CFC5F9E5EB31E50A5F22B8B5C48C8AA3750F777A5775062E8E4625FF939F67950AC2B646E2F2BEB01AB50E6266F71452H0DE8723H50B42F509F9A189F5F2HAAE92A502125DED128B40BF40A03935BD3D2143H2EAE50357D7C750F5818D0D54547C747C7502H725EF250C9411CB65FFC7CD67C50FB2CED622B363E2H76639D972HDD54206A2H605E6F4ECF64087A7B3A3903B171953150048F8E844263EB1F13283E76BB8E28C506454003A8A368695A575C1C9F10C2098715269913128E308C878804414B2H40C25B862H8D903F6D9B93D80E2H70860F50BF068DCA0E2HCACB4A500107058B41142H129D5BF32HF5E53FCE32CE3503155515955038814F0D0E3HE7675092D267ED50E9EF6968143H1C9C509B5D291B0F96D3939B447DFD8102508040090E450F4F128F502H5A72DA502H51DB414AA4E46ADB50C303F843505E14DCDE20E5A7E5E60388438A8820373C2H375E226DE10B05B973D646052CAC36AC506B626C6B42266F2H26634D8D54CD50D0DA9A904B1F2HC6462BEA2A149550216126210C2HB434301D2H5314130C2H2E6EE51D3HB53550D8989D980C07C780870C3HB2325089090C090C2HBC3CB41D7BFBBCBB0C2H76B6222H1DDC1B1D0CA02HA1271DEF2EA5AF0CFA3B737A0C3HF1715044C5C1C40CA32H62630C3HFE7E50458480850CA8AAAFA80C9795D2D70CC2002H420C3HD95950CC4E494C0CCB09020B0C46454D460C3HED6D50B0B3B5B00CBF7CF4FF0C8AC9000A0C0142C16651D410D411513HB333508E8A8B8E0C15512H5520383C2HB820E723242720D2D72HD207E9AC2HA920DCD9555C209BDE535B20D610D4D620BDBB2HBD5E0040D43117CFCAAC30052HDA1AE503512HAAE40E646DECE44203C30483509E181B2E28E5AC2524143HC84850B7BE08770FE26467522879332H79163H6CEC50ABE1D0AB0F666FE6660B3H8D0D50D0D992D00F9F16979F422AEA28AA50A121E11E03F4B4F47450935B5A5342AE2E54D15035FCF7F52018D12HD85E87D4CBB610722H7BE13089404B49203CA5EB652B3B32F2EF302HF6F576501DD4555D42203877F92BAFA6E6FC30BA7A41C55031352H315E04840C8450A363A123507E383B0E28C58532BA50A8602F6A1B2H17E96850020A8A904419D9E766508C850D8C1F2H0BCB3403864679F950ADA5253F44F079F8E1263FFFC240504ACAF73550C1CB0B014B14D4EB6B502HF3DB73500E1756D72B95156BEA50387EC7C82867A79918505293AB655CE9293A96509C2H5CE3509B12938A2116D6D96950FDBF7D8D032H000180504F058F8E143HDA5A5011DBBED10F24EE2E24424303BF3C501E1CDE5D032H659B1A5008000B08427773B48728222AAAA24BB9F942C650ACA9929C28EBAB6B9503262EA6A7148D4D454F5D10500B9050DF5F0DA050EA21E1EF1D61EA2A311D3H34B450539896930CAEAD6EEC033H35B550185807985087CC0C1F442H32CD4D5009832H89077C76BEBC20FB312H3B5EF6B95B7C551D60A1E80E60EB222H206F242H2F5EBA9001BC0FB17BB90E05044E464420A3E92HE35EBE51B7CF6185F939700E686221285C5797A82850C282C84E4759D9A226502HCC1AB350CB0CCC8532860187C8322DAA2E633230B03DB0503FB836F51B0A8D2H8A2A2H4146414254D45FD45073F4733D320E4EF07150959291DB3278BF7A3632E760E3A9322H5257D250E92CA82960DCDA2HDC07DBDD2HDB5E96A385885C7D3B2H3D0700462H405E0FB939325F9A1C2H1A0791172H115E245961B84243858B83205E982H9E5EE59CA38C25480F49482AF7772HF7422HE2E7E242F979FDF942EC2CE8EC422B6B2F2B42E6A6E3E6420D4D098D501097175E325F585C1132EA2DECA432A126A4EF3234F3357A32D35324AC50EE2B2F2E4FB5702H755E58D267FE01474145472072F272F250C9C12HC95EFC3C4383507BFB7FFB5036302H7654DD1DDF5D50E0652H60076FAF9310507A3DBA3D072HB143CE5044432H842A23A3242342FEC1BEC80345C5B93A50282F226632975768E8504245440C3299196BE6508C8A050C204BCD2HCB5EC67A3F3E266DABACAD2A7030820F502HBF07C050CA0A58B55001C001FE03945C1D804473B38D0C500E042H4E54551F2H155E38F7706221E7A7E7E40392526FED50292360FA0D5C162H1C5E1BDBBA64502H960CE950FDEAED642B40FF00FE030F4F0F8F501A522H5A07511151D150646CACA44BC303C243505ED62HDE0725ED2HE5524880088853378E875E10A29917570EF982034C0EACA5252C4B2H6BE7145066EEA626344D0DB13250D09A2H90521F55DF5F536AB5C86758216B2B2142B4346CCB502H53936C032H6EE111503565B38E2B2H9846E7502H8737F850192H00D66C4A32CCB86C1D5794E63407DD76593A029BA50A020019B232B1325093D39013502H787BF850713170712A4HCE0C1F5F2H1F2034F40C464F2H1DA76B4F6AAA112749AB09577512701D60302C095A96754906143D2000377137EC5CAC4993785735757B180FA2E22HA22A4303C3430A4HE82A4HA1494HBE0C8F3HCF4924F8388C114H4D164H1A19F200A246661A0250BF1505",229,"\103\115\117\98",232,"\u{073}\x74\114\z       \105\u{06e}\z        \x67\z         ",string,error,string.rep,...);
